from django.contrib import admin
from account_module import models

# Register your models here.


admin.site.register(models.User)
